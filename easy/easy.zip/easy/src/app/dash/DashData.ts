var DashData = {
  DashSales: {
    products: 700,
    services: 400
  }
}

export default DashData;